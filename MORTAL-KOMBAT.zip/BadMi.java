  class BadMi extends Personagem{
  public float hipnotizacao;
  public BadMi (String _nome, String _cor, int _dano_soco, int _dano_chute, float sofreHipnotizacao, int _vida){

  nome = _nome;
  cor = _cor;
  dano_soco = _dano_soco;
  dano_chute = _dano_chute;
  hipnotizacao = sofreHipnotizacao;
  vida = _vida;
    
  }
  public void Hipnose(Personagem inimigo){
  System.out.println(nome + " utilizou hipnose com sua dança por  " +hipnotizacao +" segundos.");
    
  }
}
  
