class Main {
  public static void main(String[] args) {

    Subzero sub = new Subzero ("Sub Zero", "Azul", 12, 25, 23, 100);
    
    BadMi mi = new BadMi ("BadMi", "Rosa", 9, 28, 29, 100);
    
    EduCoudet dudu = new EduCoudet ("Eduardo Coudet", "Vermelho e Branco", 14, 29, 19, 110);
    
    FelipeFrosi feli = new FelipeFrosi ("Felipe Frosi", "Branco", 12, 32, 18, 100);
    
    
    sub.Socar();
    sub.Gelo();
    mi.Hipnose();
    dudu.PressaoTotal();
    feli.Distraiu();
  }
}