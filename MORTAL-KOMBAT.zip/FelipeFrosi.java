class FelipeFrosi extends Personagem{
   public float distracao;

  public FelipeFrosi (String _nome, String _cor, int _dano_soco, int _dano_chute, float _distracao, int _vida){

  nome = _nome;
  cor = _cor;
  dano_soco = _dano_soco;
  dano_chute = _dano_chute;
  distracao = _distracao;
  vida = _vida;
    
  }
  public void Distraiu(){
    System.out.println(nome + " distraiu o adversário por " + distracao +" segundos.");
    
  }
}