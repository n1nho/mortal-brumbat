  abstract class Personagem{
  protected int vida, dano_soco, dano_chute;
  protected String nome;
  protected String cor;

  
  public void Socar (){
    System.out.println(nome + " socou com forca " + dano_soco);
  }
  public void Chutar (){
    System.out.println(nome + " chutou com dano " + dano_chute);
  }
  
}