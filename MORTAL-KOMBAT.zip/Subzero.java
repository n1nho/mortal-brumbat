class Subzero extends Personagem{
  public float tempo_congelamento;

  public Subzero (String _nome, String _cor, int _dano_soco, int _dano_chute, float _tempo_congelamento, int _vida){

  nome = _nome;
  cor = _cor;
  dano_soco = _dano_soco;
  dano_chute = _dano_chute;
  tempo_congelamento = _tempo_congelamento;
  vida = _vida;
    
  }
  public void Gelo(){
    System.out.println(nome + " utilizou congelamento com o tempo de " + tempo_congelamento +" segundos.");
    
  }
}