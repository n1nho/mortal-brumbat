class EduCoudet extends Personagem{
 public float pressao_total;
  public EduCoudet (String _nome, String _cor, int _dano_soco, int _dano_chute, float _pressao_total, int _vida){

  nome = _nome;
  cor = _cor;
  dano_soco = _dano_soco;
  dano_chute = _dano_chute;
  pressao_total = _pressao_total;
  vida = _vida;
    
  }
  public void PressaoTotal(){
  System.out.println(nome + " pressionou o adversário por " +pressao_total +" segundos.");
    
  }
}
  